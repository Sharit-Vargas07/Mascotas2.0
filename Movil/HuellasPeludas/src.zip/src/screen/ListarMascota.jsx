import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image } from 'react-native';

function ListarMascota() {
    return (
        <ScrollView contentContainerStyle={styles.container}>
            <View style={styles.petDetails}>
                <Image source={{uri: 'https://example.com/imagen.jpg'}} style={styles.petImage} />
                <Text style={styles.petName}>Hola</Text>
                <View style={styles.infoSection}>
                    <Text style={styles.infoTitle}>Historial médico:</Text>
                    <Text style={styles.infoText}>Vacunación: </Text>
                    <Text style={styles.infoText}>Esterilización/Castración: </Text>
                    <Text style={styles.infoText}>Enfermedades: </Text>
                    <Text style={styles.infoText}>Tratamientos: </Text>
                    <Text style={styles.infoText}>Tratamientos: </Text>
                    <Text style={styles.infoText}>Tratamientos: </Text>
                    <Text style={styles.infoText}>Tratamientos: </Text>
                </View>
                <View>
                    
                    <TouchableOpacity style={[styles.button, styles.cancelButton]}>
                        <Text style={styles.buttonText}>Cancelar adopción</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.button, styles.adoptButton]}>
                        <Text style={styles.buttonText}>Dar en adopción la mascota</Text>
                    </TouchableOpacity>
                </View>
            </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        backgroundColor: '#f8f9fa',
        paddingHorizontal: 20,
        paddingVertical: 25,
    },
    petDetails: {
        alignItems: 'center',
        backgroundColor: '#fff',
        borderRadius: 10,
        padding: 20,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
    },
    petImage: {
        width: '100%',
        height: 300,
        borderRadius: 10,
    },
    petName: {
        fontSize: 30,
        fontWeight: 'bold',
        marginTop: 10,
        textAlign: 'center',
        color: '#333',
    },
    infoSection: {
        width: '100%',
        marginTop: 20,
        backgroundColor: '#e9ecef',
        borderRadius: 10,
        padding: 15,
    },
    infoTitle: {
        fontSize: 22,
        fontWeight: 'bold',
        color: '#495057',
    },
    infoText: {
        fontSize: 18,
        marginTop: 5,
        color: '#6c757d',
    },
    button: {
        width: 220,
        height: 50,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#007bff',
        borderRadius: 25,
        marginVertical: 10,
    },
    cancelButton: {
        backgroundColor: '#dc3545',
    },
    adoptButton: {
        backgroundColor: '#28a745',
    },
    buttonText: {
        fontSize: 18,
        color: 'white',
        textAlign: 'center',
    },
});

export default ListarMascota;
